import React from 'react';

const EducationCard = ({
  degree,
  institution,
  period,
  description,
}: {
  degree: string;
  institution: string;
  period: string;
  description: string;
}) => (
  <div className="bg-white dark:bg-gray-700 rounded-lg p-6 shadow-lg mb-8">
    <h3 className="text-xl font-semibold mb-2 dark:text-white">{degree}</h3>
    <p className="text-blue-600 dark:text-blue-400 mb-2">{institution}</p>
    <p className="text-gray-600 dark:text-gray-300 mb-4">{period}</p>
    <p className="text-gray-700 dark:text-gray-300">{description}</p>
  </div>
);

const Education = () => {
  const education = [
    {
      degree: 'Master of Science in Computer Science',
      institution: 'West Virginia State University',
      period: '2023 – 2025',
      description:
        'Advanced studies in distributed systems, cloud computing, and artificial intelligence. Research focus on data visualization and machine learning applications.',
    },
    {
      degree: 'Bachelor of Technology in Computer Science',
      institution: 'Jawaharlal Nehru Technological University Hyderabad',
      period: '2015 – 2019',
      description:
        'Comprehensive foundation in computer science fundamentals, software engineering principles, and practical programming skills.',
    },
  ];

  return (
    <section className="py-20 dark:bg-gray-800" id="education">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 dark:text-white">Education</h2>
        <div className="max-w-4xl mx-auto">
          {education.map((edu, index) => (
            <EducationCard key={index} {...edu} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Education;