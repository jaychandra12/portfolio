import React from 'react';
import { Github, Linkedin, Mail, Phone } from 'lucide-react';

const Footer = () => {
  return (
    <footer className="bg-gray-800 text-white py-12">
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <div className="flex justify-center space-x-6 mb-8">
            <a href="https://github.com/yourusername" className="hover:text-blue-400 transition-colors">
              <Github className="w-6 h-6" />
            </a>
            <a href="https://linkedin.com/in/yourusername" className="hover:text-blue-400 transition-colors">
              <Linkedin className="w-6 h-6" />
            </a>
            <a href="mailto:jaysea.jc11@gmail.com" className="hover:text-blue-400 transition-colors">
              <Mail className="w-6 h-6" />
            </a>
            <a href="tel:+12017141140" className="hover:text-blue-400 transition-colors">
              <Phone className="w-6 h-6" />
            </a>
          </div>
          <p className="text-gray-400">
            © {new Date().getFullYear()} Jaya Chandra Gundeboina. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;