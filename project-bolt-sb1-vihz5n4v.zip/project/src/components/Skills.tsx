import React from 'react';

const SkillCategory = ({ title, skills }: { title: string; skills: string[] }) => (
  <div className="mb-8">
    <h3 className="text-xl font-semibold mb-4 dark:text-white">{title}</h3>
    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
      {skills.map((skill) => (
        <div
          key={skill}
          className="bg-white dark:bg-gray-700 rounded-lg p-4 shadow-md hover:shadow-lg transition-shadow"
        >
          <p className="text-gray-800 dark:text-gray-200">{skill}</p>
        </div>
      ))}
    </div>
  </div>
);

const Skills = () => {
  const skillCategories = {
    'Programming Languages': ['JavaScript (ES6+)', 'TypeScript', 'Python', 'SQL'],
    'Front-End Development': ['React.js', 'Next.js', 'Redux', 'Tailwind CSS', 'Bootstrap', 'Material UI'],
    'Back-End Development': ['Node.js', 'Express.js', 'RESTful APIs', 'GraphQL', 'WebSockets'],
    'Database Management': ['MongoDB', 'MySQL', 'PostgreSQL', 'Firebase'],
    'Cloud & DevOps': ['AWS (S3, EC2, Lambda)', 'Google Cloud', 'Azure', 'Docker', 'Kubernetes'],
    'Testing & Debugging': ['Jest', 'Mocha', 'Cypress', 'Postman'],
    'Version Control & Collaboration': ['Git', 'GitHub', 'Agile', 'Scrum', 'Jira'],
  };

  return (
    <section className="py-20 bg-gray-50 dark:bg-gray-900" id="skills">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 dark:text-white">Technical Skills</h2>
        <div className="max-w-4xl mx-auto">
          {Object.entries(skillCategories).map(([category, skills]) => (
            <SkillCategory key={category} title={category} skills={skills} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Skills;