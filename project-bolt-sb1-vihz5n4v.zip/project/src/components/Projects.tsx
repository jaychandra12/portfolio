import React from 'react';
import { Github, ExternalLink } from 'lucide-react';

const ProjectCard = ({
  title,
  description,
  technologies,
  github,
  demo,
}: {
  title: string;
  description: string;
  technologies: string[];
  github: string;
  demo: string;
}) => (
  <div className="bg-white dark:bg-gray-700 rounded-lg overflow-hidden shadow-lg">
    <div className="p-6">
      <h3 className="text-xl font-semibold mb-3 dark:text-white">{title}</h3>
      <p className="text-gray-600 dark:text-gray-300 mb-4">{description}</p>
      <div className="flex flex-wrap gap-2 mb-4">
        {technologies.map((tech) => (
          <span
            key={tech}
            className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-800 dark:text-blue-200 rounded-full text-sm"
          >
            {tech}
          </span>
        ))}
      </div>
      <div className="flex space-x-4">
        <a
          href={github}
          className="flex items-center text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
        >
          <Github className="w-5 h-5 mr-2" />
          Code
        </a>
        <a
          href={demo}
          className="flex items-center text-gray-600 dark:text-gray-300 hover:text-blue-600 dark:hover:text-blue-400"
        >
          <ExternalLink className="w-5 h-5 mr-2" />
          Live Demo
        </a>
      </div>
    </div>
  </div>
);

const Projects = () => {
  const projects = [
    {
      title: 'Research Data Visualization Tool',
      description:
        'Advanced data visualization platform built for research purposes, featuring AI-powered analysis tools and interactive charts.',
      technologies: ['React', 'Node.js', 'MongoDB', 'TensorFlow.js', 'D3.js'],
      github: 'https://github.com/yourusername/research-viz',
      demo: 'https://research-viz.demo',
    },
    {
      title: 'E-Commerce Platform',
      description:
        'Full-featured e-commerce solution with real-time inventory management and payment processing.',
      technologies: ['Next.js', 'Express', 'PostgreSQL', 'Stripe', 'Redis'],
      github: 'https://github.com/yourusername/ecommerce',
      demo: 'https://ecommerce.demo',
    },
    {
      title: 'Cloud-Based Task Management',
      description:
        'Scalable task management system with real-time collaboration features and automated workflows.',
      technologies: ['React', 'Node.js', 'AWS', 'WebSocket', 'MongoDB'],
      github: 'https://github.com/yourusername/task-manager',
      demo: 'https://task-manager.demo',
    },
  ];

  return (
    <section className="py-20 bg-gray-50 dark:bg-gray-900" id="projects">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 dark:text-white">Featured Projects</h2>
        <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
          {projects.map((project, index) => (
            <ProjectCard key={index} {...project} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Projects;