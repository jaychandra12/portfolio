import React from 'react';

const ExperienceCard = ({
  title,
  company,
  period,
  achievements,
}: {
  title: string;
  company: string;
  period: string;
  achievements: string[];
}) => (
  <div className="bg-white dark:bg-gray-700 rounded-lg p-6 shadow-lg mb-8">
    <h3 className="text-xl font-semibold mb-2 dark:text-white">{title}</h3>
    <p className="text-blue-600 dark:text-blue-400 mb-2">{company}</p>
    <p className="text-gray-600 dark:text-gray-300 mb-4">{period}</p>
    <ul className="list-disc list-inside space-y-2">
      {achievements.map((achievement, index) => (
        <li key={index} className="text-gray-700 dark:text-gray-300">
          {achievement}
        </li>
      ))}
    </ul>
  </div>
);

const Experience = () => {
  const experiences = [
    {
      title: 'Full Stack Developer & Research Assistant',
      company: 'West Virginia State University',
      period: '2025 – Present',
      achievements: [
        'Lead developer for research data visualization tools using MERN stack and Next.js',
        'Implemented AI-powered data analysis features',
        'Optimized application performance and reduced loading times by 40%',
      ],
    },
    {
      title: 'Software Developer',
      company: 'TopEdge Technology',
      period: '2024 – 2024',
      achievements: [
        'Developed and maintained scalable web applications using React and Node.js',
        'Implemented microservices architecture for improved system modularity',
        'Led team of 4 developers in successful project delivery',
      ],
    },
    {
      title: 'Software Developer',
      company: 'RGLOBITS',
      period: '2019 – 2023',
      achievements: [
        'Built and maintained multiple client-facing applications using MERN stack',
        'Implemented authentication systems using JWT and OAuth',
        'Optimized database performance and reduced query times by 50%',
      ],
    },
  ];

  return (
    <section className="py-20 dark:bg-gray-800" id="experience">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 dark:text-white">Work Experience</h2>
        <div className="max-w-4xl mx-auto">
          {experiences.map((exp, index) => (
            <ExperienceCard key={index} {...exp} />
          ))}
        </div>
      </div>
    </section>
  );
};

export default Experience;