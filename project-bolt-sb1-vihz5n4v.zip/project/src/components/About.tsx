import React from 'react';

const About = () => {
  return (
    <section className="py-20 dark:bg-gray-800" id="about">
      <div className="container mx-auto px-4">
        <h2 className="text-3xl font-bold text-center mb-12 dark:text-white">About Me</h2>
        <div className="max-w-4xl mx-auto">
          <div className="flex flex-col md:flex-row items-center gap-8">
            <div className="w-full md:w-1/3">
              <img
                src="/profile.jpg"
                alt="Jaya Chandra Gundeboina"
                className="rounded-full w-48 h-48 object-cover mx-auto shadow-lg"
              />
            </div>
            <div className="w-full md:w-2/3">
              <p className="text-lg mb-6 dark:text-gray-300">
                As a Full Stack Developer with over 5 years of experience, I specialize in building scalable web applications
                and cloud solutions. My expertise spans across the entire development stack, from crafting intuitive user
                interfaces to designing robust backend systems and managing cloud infrastructure.
              </p>
              <p className="text-lg mb-6 dark:text-gray-300">
                I hold a Master of Science in Computer Science from West Virginia State University and a Bachelor of
                Technology in Computer Science from Jawaharlal Nehru Technological University Hyderabad. My academic
                background, combined with extensive practical experience, allows me to approach problems with both theoretical
                depth and practical efficiency.
              </p>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default About;