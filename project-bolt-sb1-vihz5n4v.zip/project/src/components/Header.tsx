import React from 'react';
import { Github, Linkedin, Mail, Phone } from 'lucide-react';

const Header = () => {
  return (
    <header className="bg-gradient-to-r from-blue-600 to-blue-800 text-white py-20 relative overflow-hidden">
      <div className="absolute inset-0 bg-grid-pattern opacity-10"></div>
      <div className="container mx-auto px-4">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-5xl font-bold mb-4">Jaya Chandra Gundeboina</h1>
          <p className="text-xl mb-8">Seasoned Full Stack Developer | Expert in Scalable Web Applications & Cloud Solutions</p>
          <div className="flex justify-center space-x-6">
            <a href="https://github.com/yourusername" className="hover:text-blue-200 transition-colors">
              <Github className="w-6 h-6" />
            </a>
            <a href="https://linkedin.com/in/yourusername" className="hover:text-blue-200 transition-colors">
              <Linkedin className="w-6 h-6" />
            </a>
            <a href="mailto:jaysea.jc11@gmail.com" className="hover:text-blue-200 transition-colors">
              <Mail className="w-6 h-6" />
            </a>
            <a href="tel:+12017141140" className="hover:text-blue-200 transition-colors">
              <Phone className="w-6 h-6" />
            </a>
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;