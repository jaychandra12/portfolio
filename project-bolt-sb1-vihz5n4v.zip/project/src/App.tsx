import React, { useState } from 'react';
import { Moon, Sun } from 'lucide-react';
import Header from './components/Header';
import About from './components/About';
import Skills from './components/Skills';
import Experience from './components/Experience';
import Projects from './components/Projects';
import Education from './components/Education';
import Contact from './components/Contact';
import AdminMessages from './components/AdminMessages';
import Footer from './components/Footer';

function App() {
  const [darkMode, setDarkMode] = useState(false);
  const [showAdmin, setShowAdmin] = useState(false);

  const toggleDarkMode = () => {
    setDarkMode(!darkMode);
  };

  // Secret key combination: Press 'A' + 'M' together
  const handleKeyDown = (e: KeyboardEvent) => {
    if (e.key === 'a' && e.altKey) {
      setShowAdmin(!showAdmin);
    }
  };

  React.useEffect(() => {
    document.addEventListener('keydown', handleKeyDown);
    return () => {
      document.removeEventListener('keydown', handleKeyDown);
    };
  }, [showAdmin]);

  return (
    <div className={`min-h-screen ${darkMode ? 'dark bg-gray-900' : 'bg-white'}`}>
      <div className="fixed top-4 right-4 z-50">
        <button
          onClick={toggleDarkMode}
          className="p-2 rounded-full bg-gray-200 dark:bg-gray-700 hover:bg-gray-300 dark:hover:bg-gray-600 transition-colors"
          aria-label="Toggle dark mode"
        >
          {darkMode ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
        </button>
      </div>
      <Header />
      <main className="container mx-auto px-4 py-8">
        {showAdmin ? (
          <AdminMessages />
        ) : (
          <>
            <About />
            <Skills />
            <Experience />
            <Projects />
            <Education />
            <Contact />
          </>
        )}
      </main>
      <Footer />
    </div>
  );
}

export default App;