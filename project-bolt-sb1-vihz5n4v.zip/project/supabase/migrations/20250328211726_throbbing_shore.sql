/*
  # Create email messages table for notification system

  1. New Tables
    - `email_messages`
      - `id` (uuid, primary key)
      - `to_email` (text)
      - `subject` (text)
      - `content` (text)
      - `status` (text) - For tracking email status (pending, sent, failed)
      - `created_at` (timestamp)
      - `sent_at` (timestamp, nullable)
  
  2. Security
    - Enable RLS on `email_messages` table
    - Add policy for edge functions to insert messages
    - Add policy for authenticated users to read messages
*/

CREATE TABLE IF NOT EXISTS email_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  to_email text NOT NULL,
  subject text NOT NULL,
  content text NOT NULL,
  status text DEFAULT 'pending',
  created_at timestamptz DEFAULT now(),
  sent_at timestamptz
);

ALTER TABLE email_messages ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Edge functions can insert messages"
  ON email_messages
  FOR INSERT
  TO service_role
  WITH CHECK (true);

CREATE POLICY "Only authenticated users can view messages"
  ON email_messages
  FOR SELECT
  TO authenticated
  USING (true);